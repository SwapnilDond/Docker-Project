def call(){
  sh "trivy fs ."
}
